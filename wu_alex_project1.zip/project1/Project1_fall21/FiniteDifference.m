function [J] = FiniteDifference(x, func)
    % FiniteDifference.m
    %   First-order finite difference approximation of a function
    %
    % Arguments:
    %   x: P represented as a design parameter column vector
    %   func: anonymous function that returns double type
    %
    % Returns:
    %   J: Jacobian

    h=1e-8;
    J=[];
    for i=1:size(x,1)
        xc=x;
        xc(i)=xc(i)+h;
        J = [J, (func(xc)-func(x))/h];
    end
    J = J';
end