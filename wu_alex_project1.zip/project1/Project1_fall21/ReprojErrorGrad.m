function [error, g] = ReprojErrorGrad(x, p3d, p2d, display)
    % ReprojErrorGrad.m
    %   Calculate reprojection error as the objective function in nonlinear
    %   camera calibration. Calculate objective function gradient
    %   using first-order finite difference approximation
    %
    % Arguments:
    %   x: P represented as a design parameter column vector
    %   p3d: matrix of 3D points
    %   p2d: matrix of 2D points
    %   display: whether or not to display intermediates in ReprojError
    %
    % Returns:
    %   error: reprojection error
    %   g: gradient of reprojection error

    error = ReprojError(x, p3d, p2d, display);
    g = FiniteDifference(x,@(x)ReprojError(x, p3d, p2d, display));
end