function [cineq, c] = OrthCons(x)
    % OrthConsJac.m
    %   Calculate orthonormality constraint values
    %
    % Arguments:
    %   x: P represented as a design parameter column vector
    %
    % Returns:
    %   c: orthonormality constraint values

    cineq = [];
    c = [norm(x(9:11,1))-1;
        cross(x(1:3,1),x(9:11,1)).*cross(x(5:7,1),x(9:11,1))];
end