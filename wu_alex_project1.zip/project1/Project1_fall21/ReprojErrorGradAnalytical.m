function [error, g] = ReprojErrorGradAnalytical(x, p3d, p2d, display)
    % ReprojErrorGradAnalytical.m
    %   Calculate reprojection error as the objective function in nonlinear
    %   camera calibration. Calculate objective function gradient
    %   analytically to be supplied to fmincon
    %
    % Arguments:
    %   x: P represented as a design parameter column vector
    %   p3d: matrix of 3D points
    %   p2d: matrix of 2D points
    %   display: whether or not to display intermediates in ReprojError
    %
    % Returns:
    %   error: reprojection error
    %   g: gradient of reprojection error

    error = ReprojError(x, p3d, p2d, display);
    g = zeros(size(x,1),1);
    
    % Manually initialize the gradient of Vhat
    dvhat = [];
    for i=1:size(p3d,2)
        M=p3d(:,i)';
        p1 = x(1:3,1);
        p14 = x(4,1);
        p2 = x(5:7,1);
        p24 = x(8,1);
        p3 = x(9:11,1);
        p34 = x(12,1);

        dvhat_p1 = [M'/(M*p3+p34),zeros(3,1)]';
        dvhat_p14 = [1/(M*p3+p34);0];
        dvhat_p2 = [zeros(3,1),M'/(M*p3+p34)]';
        dvhat_p24 = [0;1/(M*p3+p34)];
        dvhat_p3 = [(-1*(M*p1+p14)*(M))/(M*p3+p34)^2,
            (-1*(M*p2+p24)*(M))/(M*p3+p34)^2];
        dvhat_p34 = [-1*(M*p1+p14)/(M*p3+p34)^2;
            -1*(M*p2+p24)/(M*p3+p34)^2];
        
        dvhat = [dvhat; [dvhat_p1,dvhat_p14,dvhat_p2,dvhat_p24,...
            dvhat_p3,dvhat_p34]];
    end
    P=[x(1:4,1)';x(5:8,1)';x(9:12,1)'];
    diff = [];
    for i=1:size(p3d,2)
        lhs = [p2d(:,i);1];
        rhs = (1/P(3,4))*P*[p3d(:,i);1];
        diff3 = rhs - lhs;
        diff = [diff; diff3(1:2,:)];
    end
    g = 2*dvhat'*diff;
end