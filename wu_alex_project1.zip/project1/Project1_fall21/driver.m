function [] = driver(p3d_file, p2d_file, grad_setting)
    % driver.m 
    %   1. Read 3D and 2D points from text file
    %   2. Sample 6 3D/2D pairs (random, split sampling)
    %   3. Solve projection matrix using orthonormal constrained linear
    %   method until reprojection error is below a threshold
    %   4. Perform full orthonormal constrained nonlinear calibration with
    %   linear P as initial design parameters
    %   5. Extract camera parameters
    %   6. Verify orthonormality conditions in rotation matrix
    %
    % Arguments:
    %   p3d_file: name of 3D point file
    %   p2d_file: name of 2D point file
    %   grad_setting: how to compute objective function gradient during
    %   nonlinear calibration(either 'FiniteDifference' or 'Analytical')
    %
    % Returns:
    %   None
    %
    % Example usage: driver("resources/3Dpointnew.txt",...
    %                       "resources/Left_2Dpoints.txt",...
    %                       'FiniteDifference')
    close all;
    p3d = ParseMat(p3d_file);
    p2d = ParseMat(p2d_file);
    figure(1);
    scatter3(p3d(1,:),p3d(2,:),p3d(3,:));
    title("3D Points");
    figure(2);
    scatter(p2d(1,:),p2d(2,:));
    title("2D Points from 'Right' Perspective");

    % Randomly sample and evaluate P until reprojection error is below a
    % tolerance
    while true
        P_init = CalibrateCamera(p3d, p2d, 3, 3, false, false);
        x0 = [P_init(1,1:4)';P_init(2,1:4)';P_init(3,1:4)'];
        error = ReprojError(x0, p3d, p2d, false);
        if error < 20^4
            break;
        end
    end
    disp("Initial projection matrix:");
    disp(P_init);
    disp("Average reprojection error pre-optimization:");
    disp(error/size(p3d,2));

    figure(2);
    hold on;
    p2rep = [];
    for i=1:size(p3d,2)
        p2rep = [p2rep,(1/P_init(3,4))*P_init*[p3d(:,i);1]];
    end
    scatter(p2rep(1,:),p2rep(2,:),'x','green');
    
    % Implement unconstrained complex-step gradient descent to refine P
    % No need to constrain for orthonormality since CalibrateCamera already
    % handles it
    % Design parameters: entries in P
    % Objective function: reprojection error
    % Any other bounds on projection matrix?
    %   Complex step doesn't work for some reason?
    if grad_setting == "FiniteDifference"
        options = optimoptions('fmincon','Algorithm','interior-point',...
                    'MaxFunctionEvaluations', 10*10^3,...
                    'GradObj','on',...
                    'GradConstr','off',...
                    'Display','iter');
        x = fmincon(@(x)ReprojErrorGrad(x,p3d,p2d,false),x0,[],[],[],[],[],[],...
            @(x)OrthConsJac(x),options);
        P=[x(1:4,1)';x(5:8,1)';x(9:12,1)'];
    elseif grad_setting == "Analytical"
        options = optimoptions('fmincon','Algorithm','interior-point',...
                    'MaxFunctionEvaluations', 10*10^3,...
                    'GradObj','on',...
                    'GradConstr','off',...
                    'Display','iter');
        x = fmincon(@(x)ReprojErrorGradAnalytical(x,p3d,p2d,false),x0,...
            [],[],[],[],[],[],...
            @(x)OrthConsJac(x),options);
        P=[x(1:4,1)';x(5:8,1)';x(9:12,1)'];
    else
        disp('Invalid gradient approximation method');
        exit;
    end

    disp("Optimized projection matrix:");
    disp(P);
    disp("Average reprojection error post-optimization:");
    disp(ReprojError(x, p3d, p2d, false)/size(p3d,2));

    % Finally, recover camera parameters from projection matrix
    r3 = P(3,1:3);
    tz = P(3,4);
    co = P(1,1:3)*P(3,1:3)';
    ro = P(2,1:3)*P(3,1:3)';
    sxf = (P(1,1:3)*P(1,1:3)'-co^2)^(1/2);
    syf = (P(2,1:3)*P(2,1:3)'-ro^2)^(1/2);
    tx = (P(1,4)-co*tz)/sxf;
    ty = (P(2,4)-ro*tz)/syf;
    r1 = (P(1,1:3)-co*P(3,1:3))/sxf;
    r2 = (P(2,1:3)-ro*P(3,1:3))/syf;

    disp("R:");
    R = [r1; r2; r3];
    disp(R);
     disp("T:");
     T = [tx; ty; tz];
     disp(T);
    disp("W:");
    W = [sxf, 0, co;
        0, syf, ro;
        0, 0, 1];
    disp(W);

    figure(2);
    hold on;
    p2rep = [];
    for i=1:size(p3d,2)
        p2rep = [p2rep,(1/P(3,4))*P*[p3d(:,i);1]];
    end
    scatter(p2rep(1,:),p2rep(2,:),'x','red');
    legend('GTruth', 'Lin', 'Lin+NonLin');
    
    % Verifications
    % R must be orthonormal
    disp("Orthonormality of R:");
    disp(norm(r1));
    disp(norm(r2));
    disp(norm(r3));
    disp(cross(r1,r3).*cross(r2,r3));
    
    % There are many viable solutions for P. Running the entire calibration
    % process multiple times yielded many different P.
end