function [J] = ComplexStep(x, func)
    % complex_step.m
    %   Compute general complex step Jacobian
    %   
    %   Usage: complex_step([0.03; 0.03; 0.03; 0.005; 0.005; 0.005],
    %                       @(x)max_stress(x,L,E,UTS,Nelem,force))
    %   Arguments:
    %       x: vector of design parameters. Assumes column vector of the form
    %       [inner radii; thicknesses]
    %       func: function that takes x and returns a column vector of any
    %       form
    %   Returns:
    %       J: jacobian computed via complex step
    h=1e-60;
    J=[];
    for i=1:size(x,1)
        xc=x;
        xc(i)=xc(i)+complex(0,h);
        J = [J, imag(func(xc))/h];
    end
    J = J';
end