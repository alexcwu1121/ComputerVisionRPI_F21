function [cineq, c, Jineq, J] = OrthConsJac(x)
    % OrthConsJac.m
    %   Calculate orthonormality constraint values and Jacobian for
    %   nonlinear camera calibration feasibility conditions using
    %   first-order finite difference approximation
    %
    % Arguments:
    %   x: P represented as a design parameter column vector
    %
    % Returns:
    %   c: orthonormality constraint values
    %   J: Jacobian of orthonormality constraints

    [cineq, c] = OrthCons(x);
    Jineq = [];
    J = FiniteDifference(x,@(x)OrthCons(x));
    disp(J);
end